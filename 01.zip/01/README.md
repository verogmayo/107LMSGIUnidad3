# Ejemplo 1.- Acceso y modificación de elementos del DOM 

>  Crea un script que mofique el contenido:

*  título (titulo)
*  parrafos (clase parrafo), cada parrafo con un texto diferente.

>  Mofificar los estilos style de cada elemento.

*  Cuerpo: color de fondo:  #f4f4f4;   Fondo gris claro  y  texto centrado
*  Titulo: color #333, negrita, margen inferior 15px y en mayúsculas (text-transform:uppercase).
*  Parrafos: Tamaño fuente 18px,  padding 10px, ancho 60%, border izquierdo 5px solido, border radio 5px y altura línea 1.6
*  Parrafo 1: color fuente  rojo #e74c3c; , color fondo: #ffe6e6, color borde: #c0392b
*  Parrafo 2: color fuente verde #2ecc71, color de fondo: #eaffea, color borde: #27ea60
*  Parrafo 3: color fuente azul #3498db color de fondo: #e6f2ff, color borde: #2980b9
